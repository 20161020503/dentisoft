import os
from flask import Flask, render_template, request, redirect, session, url_for, redirect
from flask_sqlalchemy import SQLAlchemy

from datetime import datetime #le da la fecha actual al usuario

#Busqueda a través de archivos a la bd
project_dir = os.path.dirname(os.path.abspath(__file__))
database_file = "sqlite:///{}".format(os.path.join(project_dir, "dentisoftdatabase.db"))

#añade bd a flask
app = Flask(__name__)
app.config["SQLALCHEMY_DATABASE_URI"] = database_file
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
app.secret_key = 'my_secret_key' #Necesaria para el uso de cookies, dato para encriptar
db = SQLAlchemy(app)

#crea la tabla User
class User(db.Model):
    name = db.Column(db.String(80), unique=False, nullable=False)
    email = db.Column(db.String(80), unique=True, nullable=False)
    Idtype = db.Column(db.String(80), unique=False, nullable=False)
    Id = db.Column(db.String(80), unique=True, nullable=False, primary_key=True)
    password = db.Column(db.String(80), unique=False, nullable=False)
    birthDate = db.Column(db.String(80), unique=False, nullable=False)

    def __repr__(self):
        return "<Name: {}>".format(self.name),"<Email: {}>".format(self.name),"<Idtype: {}>".format(self.name),"<Id: {}>".format(self.name),"<password: {}>".format(self.name),"<birthdate: {}>".format(self.name),

class Cita(db.Model):
    Idcita = db.Column(db.Integer, unique=True, nullable=False, primary_key=True)
    fecha = db.Column(db.String(80), unique=False, nullable=False)
    especialidad = db.Column(db.String(80), unique=False, nullable=False)
    Odontologo = db.Column(db.String(80), unique=False, nullable=False)
    id_cliente = db.Column(db.String(80), unique=False, nullable=False)
    hora = db.Column(db.String(80), unique=False, nullable=False)
    
    def __repr__(self):
        return "<Idcita: {}>".format(self.Idcita),"<Fecha: {}>".format(self.fecha),"<Especialidad: {}>".format(self.especialidad),"<Odontologo: {}>".format(self.Odontologo),"<id_cliente: {}>".format(self.id_cliente), "<hora: {}>".format(self.hora),

class Especialista(db.Model):
    id_especialista = db.Column(db.String(80), unique=True, nullable=False, primary_key=True)
    nombre = db.Column(db.String(80), unique=False, nullable=False)
    apellido = db.Column(db.String(80), unique=False, nullable=False)
    especialidad = db.Column(db.String(80), unique=False, nullable=False)
    disponibilidad = db.Column(db.Integer, unique=False, nullable=False)
    
    def __repr__(self):
        return "<id_especialista: {}>".format(self.id_especialista),"<nombre: {}>".format(self.nombre),"<apellido: {}>".format(self.apellido),"<especialidad: {}>".format(self.especialidad),"<disponibilidad: {}>".format(self.disponibilidad),


@app.route('/')
def Index():
    return render_template('index.html')

#Carga formulario para registrarse
@app.route('/registro')
def registro():
    return render_template('registro.html')

#Trae la info del formulario y la guarda en la bd, redirige al ingreso
@app.route('/completa_registro', methods=['POST'])
def completa_registro():
    if request.form:
        try:
            user = User(name=request.form.get("name"),
                        email=request.form.get("email"),
                        Idtype=request.form.get("Idtype"),
                        Id=request.form.get("Id"),
                        password=request.form.get("password"),
                        birthDate=request.form.get("birthDate")
                        )
            db.session.add(user)
            db.session.commit()
            return render_template("ingreso.html", user = None)
        except Exception as e:
            print("Failed to add user")
            print(e)

    
    
    
#Formulario para ingresar usuario y clave
@app.route('/ingreso')
def ingreso():
    return render_template('ingreso.html', user = True)
    

#Página inicial del cliente
@app.route('/paciente_inicial', methods=['GET','POST'])
def paciente_inicial():
    if request.method == 'POST':
        id_formulario=request.form.get("Id")
        password_formulario=request.form.get("password")
        registro_busqueda_usuario = User.query.filter_by(Id=id_formulario).first()
        registro_busqueda_clave = User.query.filter_by(password=password_formulario).first()
        
        if registro_busqueda_usuario is None or registro_busqueda_clave is None:

            return render_template('ingreso.html',user = False) #Avisa que se metieron mal los datos
        elif registro_busqueda_clave.Id == registro_busqueda_usuario.Id:
            
            sesion_usuario = registro_busqueda_usuario
            session['username'] = id_formulario=request.form.get("Id")
            return render_template('/pacientes/paciente_inicial.html', sesion_usuario = sesion_usuario, fecha=datetime.now())

        else:
            return render_template('ingreso.html',user = False) #Avisa que se metieron mal los datos
    elif 'username' in session:
        sesion_usuario=User.query.filter_by(Id=session['username']).first()
        return render_template('/pacientes/paciente_inicial.html', sesion_usuario = sesion_usuario, fecha=datetime.now())
        
        

@app.route('/paciente_agenda', methods=['GET','POST'])
def paciente_agenda():
    username=session['username']#Recoje el dato de la cookie
    cita_agendada=False

    if request.form and 'especialidad' not in session:
        session['especialidad'] = id_formulario=request.form.get("especialidad")#Se crea cookie para que al llamar otra vez la misma página, persista
        
        #especialistas = Especialista.query.all() ----------------------- ENTREGA 30 SEPTIEMBRE-----------------------------------Modificar tabla especialistas pa' la próxima
        return render_template('/pacientes/paciente_agendar.html', especialidad = True, esp_select=session['especialidad'], fecha=datetime.now())#Se envía especialidad true para que se desbloquee html con verificación
    else:
        try:
            cita = Cita(fecha=request.form.get("fecha_cita"),
                        especialidad=request.form.get("especialidad"),
                        Odontologo=request.form.get("odontologos"),
                        id_cliente=username,
                        hora = request.form.get("hora_cita")
                        )
            db.session.add(cita)
            db.session.commit()
            session.pop('especialidad')#Elimina las cookies de la sesión    
            cita_agendada=True #Para que salga la alerta de que se registró la cita
        except Exception as e:
            print("Failed to add cita")
            print(e) 
        return render_template('/pacientes/paciente_agendar.html', epecialidad=False, cita_agendada=cita_agendada, fecha=datetime.now())




@app.route('/paciente_tus_citas')
def paciente_tus_citas():
    if request.method == 'GET':
        citas = Cita.query.filter_by(id_cliente=session['username']).all()#Para listar las citas
        sesion_usuario=User.query.filter_by(Id=session['username']).first()
        return render_template('/pacientes/paciente_tus_citas.html', sesion_usuario = sesion_usuario, citas=citas)
    


@app.route('/logout')
def logout():
    if 'username' in session:
        session.pop('username')#Elimina las cookies de la sesión
    if 'especialidad' in session:
        session.pop('especialidad')#Elimina las cookies de la sesión
    return redirect(url_for('ingreso'))#Busca la url de la función ingreso, no del html

if __name__ == '__main__':
    app.run(port = 3000 ,debug = True)

