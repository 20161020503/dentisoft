import os

from flask import Flask
from flask import render_template
from flask import request
from flask import redirect

from flask_sqlalchemy import SQLAlchemy

project_dir = os.path.dirname(os.path.abspath(__file__))
database_file = "sqlite:///{}".format(os.path.join(project_dir, "dentisoftdatabase.db"))

app = Flask(__name__)
app.config["SQLALCHEMY_DATABASE_URI"] = database_file
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

db = SQLAlchemy(app)

class User(db.Model):
    name = db.Column(db.String(80), unique=False, nullable=False)
    email = db.Column(db.String(80), unique=True, nullable=False)
    Idtype = db.Column(db.String(80), unique=False, nullable=False)
    Id = db.Column(db.String(80), unique=True, nullable=False, primary_key=True)
    password = db.Column(db.String(80), unique=False, nullable=False)
    birthDate = db.Column(db.String(80), unique=False, nullable=False)

    def __repr__(self):
        return "<Name: {}>".format(self.name),"<Email: {}>".format(self.name),"<Idtype: {}>".format(self.name),"<Id: {}>".format(self.name),"<password: {}>".format(self.name),"<birthdate: {}>".format(self.name),



@app.route("/", methods=["GET", "POST"])
def home():
    users = None
    if request.form:
        try:
            user = User(name=request.form.get("name"),
                        email=request.form.get("email"),
                        Idtype=request.form.get("Idtype"),
                        Id=request.form.get("Id"),
                        password=request.form.get("password"),
                        birthDate=request.form.get("birthDate")
                        )
            db.session.add(user)
            db.session.commit()
        except Exception as e:
            print("Failed to add user")
            print(e)
    users = User.query.all()
    return render_template("home.html", users=users)


@app.route("/update", methods=["POST"])
def update():
    try:
        newId = request.form.get("newId")
        oldId = request.form.get("oldId")

        newname = request.form.get("newname")
        oldname = request.form.get("oldname")

        newemail = request.form.get("newemail")
        oldemail = request.form.get("oldemail")

        newIdtype = request.form.get("newIdtype")
        oldIdtype = request.form.get("oldIdtype")

        newpassword = request.form.get("newpassword")
        oldpassword = request.form.get("oldpassword")

        newbirthDate = request.form.get("newbirthDate")
        oldbirthDate = request.form.get("oldbirthDate")

        user = User.query.filter_by(Id=oldId).first()

        user.name = newname
        user.email = newemail
        user.Idtype = newIdtype
        user.Id = newId
        user.password = newpassword
        user.birthDate = newbirthDate
        db.session.commit()
    except Exception as e:
        print("Couldn't update user name")
        print(e)
    return redirect("/")


@app.route("/delete", methods=["POST"])
def delete():
    id = request.form.get("id")
    user = User.query.filter_by(Id=id).first()
    db.session.delete(user)
    db.session.commit()
    return redirect("/")


if __name__ == "__main__":
    db.create_all()
    app.run(host='0.0.0.0', port=8087, debug=True)
